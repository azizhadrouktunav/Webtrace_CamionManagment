import { Component, OnInit } from '@angular/core';
import { TireManagementService } from '../services/tire-management.service';
import { TireManagement, DicoTransportation } from '../interfaces/tire-management';
import { ActivatedRoute } from '@angular/router';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-tire-diagram',
  templateUrl: './tire-diagram.component.html',
  styleUrls: ['./tire-diagram.component.scss']
})
export class TireDiagramComponent implements OnInit {
  ListTires: Array<TireManagement>=[];
  ListTires1: Array<TireManagement>=[];
  searchkey;
  DisabledAxle=true;
  axle1="assets/icons/flags/axleV.png";
  axle2="assets/icons/flags/axleV.png";
  axle3="assets/icons/flags/axleV.png";
  axle4="assets/icons/flags/axleV.png";
  axle5="assets/icons/flags/axleV.png";
  axle6="assets/icons/flags/axleV.png";
  KeyCar:number;
  Transportation: DicoTransportation;
  constructor(private _TireManagementService: TireManagementService,private _Activatedroute: ActivatedRoute) { }



  todo = [
    'Get to work',
    'Pick up groceries',
    'Go home',
    'Fall asleep'
  ];

  done = [
    'Get up',
    'Brush teeth',
    'Take a shower',
    'Check e-mail',
    'Walk dog'
  ];

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }
  ngOnInit() {
    this.KeyCar= Number( this._Activatedroute.snapshot.paramMap.get("Key"));
    this._TireManagementService.getTireParam().subscribe((data: any) => {
      let ListTrans:Array<DicoTransportation>= json2array(data.DicoTransportation);
      this.Transportation= ListTrans.find(x=>x.Key==this.KeyCar);
       if(this.Transportation.Axle1Enabled){
         this.axle1="assets/icons/flags/axleV.png";
       }
       else{
         this.axle1="";
       }
       if(this.Transportation.Axle2Enabled){
        this.axle2="assets/icons/flags/axleV.png";
      }
      else{
        this.axle2="";
      }
      if(this.Transportation.Axle3Enabled){
        this.axle3="assets/icons/flags/axleV.png";
      }
      else{
        this.axle3="";
      }
      if(this.Transportation.Axle4Enabled){
        this.axle4="assets/icons/flags/axleV.png";
      }
      else{
        this.axle4="";
      }
      if(this.Transportation.Axle5Enabled){
        this.axle5="assets/icons/flags/axleV.png";
      }
      else{
        this.axle5="";
      }
      if(this.Transportation.Axle6Enabled){
        this.axle6="assets/icons/flags/axleV.png";
      }
      else{
        this.axle6="";
      }



    });
    this._TireManagementService.getTires().subscribe((ListTires: TireManagement[]) => {

      ListTires.forEach(row=>{
        if(row.TireCarStatus ==0)
           this.ListTires.push(row);

      });
      

    })
  }

  openAddTireDialog(){}
  applyfilter(){}
  onDragStart(ev) {
    console.log('dragstart', ev);
    ev.dataTransfer.setData("text", ev.target.id);
  }
  onDrop(ev) {
    console.log('drop', ev);
    ev.preventDefault();
    ev.stopPropagation();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
  }
  dropp(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.ListTires, event.previousIndex, event.currentIndex);
  }
  dropb(event: CdkDragDrop<string[]>) {
    console.log(event)
    console.log(this.ListTires1)
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }

  onDragOver(ev) {
    ev.preventDefault();
    ev.stopPropagation();
  }

}
function json2array(json) {
  var result = [];
  var keys = Object.keys(json);
  keys.forEach(function (key) {
      result.push(json[key]);
  });
  return result;
}


